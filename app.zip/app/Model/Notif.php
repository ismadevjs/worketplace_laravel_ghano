<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Notif extends Model
{
   protected $table = "notifications_jdidas";
}
